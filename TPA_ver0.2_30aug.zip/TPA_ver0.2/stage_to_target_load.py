from subprocess import Popen, PIPE
import cx_Oracle
import csv
import sys
from create_db_connection import CreateDbConnection
from execute_dml_query import ExecuteDmlQuery
#import logging framework goes here
class Stage_To_TargetLoad():
    def __init__(self):
        print("Program purpose: This module reads the staging table data and inserts the same into the target tables")
    def fn_insert_data_to_target(self,inp_records):
        try:
            print("Program stating to insert into core tables")
            print(inp_records)
            column_string=""
            values_string=""
            insert_query_1=""
            var=","
            lines=[]
            i=0
            v_connection_obj = CreateDbConnection()
            v_connection = v_connection_obj.fn_connect_to_db()
            values_string = ":1,:2"
            insert_query_1 = "insert into NAV_SPECTRA_CORE (C1, C2) values ( "+values_string +")"
            print insert_query_1
            for row in inp_records:
                print row
                if(i > 2):
                    repo_db_conn = cx_Oracle.connect ( 'metadata/METADATA@orcl' )
                    cur=repo_db_conn.cursor()
                    cur.executemany(insert_query_1,lines)
                    repo_db_conn.commit()
                    lines=[]
                    cur.close()
                    lines=[]
                    i=0
                    lines.append(row)
                else:
                    i +=1
                    lines.append(row)
            repo_db_conn = cx_Oracle.connect ( 'metadata/METADATA@orcl' )
            cur=repo_db_conn.cursor()
            print lines
            cur.executemany(insert_query_1,lines)
            repo_db_conn.commit()
            lines=[]
            cur.close()
        except Exception as error:
            print("Error in program. Unable to execute the section")
            raise